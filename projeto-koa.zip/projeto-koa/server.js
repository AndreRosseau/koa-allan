const Koa = require('koa');
const Router = require('koa-router');
const bodyParser = require('koa-bodyparser');

const app = new Koa();
const router = new Router();

// Middleware
app.use(bodyParser());

// Rota GET - Tela com formulário
router.get('/', async (ctx) => {
  ctx.body = `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Cadastro Koa</title>
        <style>
            body {
                font-family: Arial;
                background: #f4f4f4;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
            .container {
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
                width: 300px;
            }
            input {
                width: 100%;
                padding: 10px;
                margin: 10px 0;
            }
            button {
                width: 100%;
                padding: 10px;
                background: #007BFF;
                color: white;
                border: none;
                cursor: pointer;
            }
            button:hover {
                background: #0056b3;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Cadastro</h2>
            <form action="/submit" method="POST">
                <input type="text" name="nome" placeholder="Digite seu nome" required />
                <input type="email" name="email" placeholder="Digite seu email" required />
                <button type="submit">Enviar</button>
            </form>
        </div>
    </body>
    </html>
  `;
});

// Rota POST - Recebe dados
router.post('/submit', async (ctx) => {
  const { nome, email } = ctx.request.body;

  ctx.body = `
    <h1>Dados Recebidos</h1>
    <p><strong>Nome:</strong> ${nome}</p>
    <p><strong>Email:</strong> ${email}</p>
    <a href="/">Voltar</a>
  `;
});

app
  .use(router.routes())
  .use(router.allowedMethods());

app.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});